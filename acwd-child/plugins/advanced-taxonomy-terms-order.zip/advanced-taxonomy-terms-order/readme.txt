===  Advanced Taxonomy Terms Order  ===
Contributors: Nsp Code
Tags: terms order, taxonomy order, taxonomy terms order
Requires at least: 3.2

Order Taxonomy Terms Objects using a Drag and Drop Sortable javascript capability

== Description ==

Advanced Taxonomy Terms Order Objects using a Drag and Drop Sortable javascript capability
It allow to reorder the terms for any taxonomy you defined, including the default Category. Also you use the new order for the Admin Interface.

== Installation ==

1. Upload `advanced-taxonomy-terms-order` folder to your `/wp-content/plugins/` directory.
2. Activate the plugin from Admin > Plugins menu.
3. Once activated you should check with Settings > Taxonomy Terms Order 
4. Use Taxonomy Order link which appear under each Post Type section to make your sort.


== Upgrade Notice ==

Make sure you deactivate the Free  - Taxonomy Terms Order - plug-in if installed.


== Localization ==

Currently only available in English.
